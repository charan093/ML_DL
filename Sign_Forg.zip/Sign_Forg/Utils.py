# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 15:22:51 2019

@author: 1577479
"""

import os
import shutil
import matplotlib.pyplot as plt
import random

train_dir_original=('C:\\Users\\1577479\\Desktop\\Sign_Forg\\Train')
test_dir_original=('C:\\Users\\1577479\\Desktop\\Sign_Forg\\Test')
target_base_dir=('C:\\Users\\1577479\\Desktop\\Sign_Forg\\Target')
val_percent=0.2

def preapare_full_dataset_for_flow(train_dir_original, test_dir_original, target_base_dir, val_percent=0.2):    
    train_dir = os.path.join(target_base_dir, 'Train')
    validation_dir = os.path.join(target_base_dir, 'Validation')
    test_dir = os.path.join(target_base_dir, 'Test')

    if not os.path.exists(target_base_dir):          
        os.makedirs(target_base_dir)
        os.makedirs(train_dir)
        os.makedirs(validation_dir)
        os.makedirs(test_dir)

cwd = os.getcwd()
print(cwd)
os.chdir('C:\\Users\\1577479\\Desktop\\Sign_Forg')
------------------
        for c in range(0,1,1): 
            os.mkdir(os.path.join(train_dir, 'c'+str(c)))
            os.mkdir(os.path.join(validation_dir, 'c'+str(c)))
        os.mkdir(os.path.join(test_dir, 'images'))
        print('created the required directory structure')
-----------------        
        
train_classes = os.listdir(train_dir_original)
        
        train_files = list()
        for cls in train_classes:
            print(cls)
            dir_path = os.path.join(train_dir_original, cls)
            print(dir_path)
            files = os.listdir(dir_path)
            for f in files:
                train_files.append(os.path.join(dir_path, f))
            
        len(train_files)
        random.shuffle(train_files)
        n = int(len(train_files) * val_percent)
        val = train_files[:n]
        train = train_files[n:]  

        for t in train:
            print(t)
            if 'c0' in t:
                print('0')
                shutil.copy2(t, os.path.join(train_dir, 'c0'))
            
        for v in val:
            print(v)
            if 'c0' in v:
                print('0')
                shutil.copy2(v, os.path.join(validation_dir, 'c0'))
                
        files = os.listdir(test_dir_original)
        test_files = [os.path.join(test_dir_original, f) for f in files]
        
----------------------------------------
        for t in test_files:
            shutil.copy2(t, os.path.join(test_dir, 'images'))
    else:
        print('required directory structure already exists. learning continues with existing data')
----------------------------------------

    nb_train_samples = 0
    nb_validation_samples = 0
    for c in range(0,1,1):
        nb_train_samples = nb_train_samples + len(os.listdir(os.path.join(train_dir, 'c'+str(c))))
    print('total training images:', nb_train_samples)
    for c in range(0,1,1):
        nb_validation_samples = nb_validation_samples + len(os.listdir(os.path.join(validation_dir, 'c'+str(c))))
    print('total validation images:', nb_validation_samples)
    nb_test_samples = len(os.listdir(os.path.join(test_dir, 'images')))
    print('total test images:', nb_test_samples )
    
    return train_dir, validation_dir, test_dir, nb_train_samples, nb_validation_samples, nb_test_samples


def plot_loss_accuracy(history):
    acc = history.history['acc']
    val_acc = history.history['val_acc']
    epochs = range(len(history.epoch))
    plt.plot(epochs, acc, 'bo', label='Training acc')
    plt.plot(epochs, val_acc, 'b', label='Validation acc')
    plt.title('Training and validation accuracy')
    plt.legend()
    
    plt.figure()
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    plt.plot(epochs, loss, 'bo', label='Training loss')
    plt.plot(epochs, val_loss, 'b', label='Validation loss')
    plt.title('Training and validation loss')
    plt.legend()

    plt.show()